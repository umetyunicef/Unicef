import './App.css';
import React from 'react';
import VideoManager from './Components/VideoManager';

export default function App() {
  return (
    <>
      <VideoManager />
    </>
  )
}
